from django.shortcuts import render
from .models import Reg
def index(request):
	if request.method=="POST":
		obj = Reg(uname=request.POST["txtuname"],upass=request.POST["txtupass"],uemail=request.POST["txtuemail"],umobile=request.POST["txtumobile"])
		obj.save()
		return render(request,"guestapp/index.html",{'res':'data inserted sucessfully'})


	return render(request,"guestapp/index.html")


def showreg(request):
	r = Reg.objects.all()
	return render(request,"guestapp/showreg.html",{'key':r})


